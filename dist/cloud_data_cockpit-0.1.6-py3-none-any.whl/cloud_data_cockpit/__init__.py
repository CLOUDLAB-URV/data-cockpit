"""DataCockpit package entry point."""
from .core import DataCockpit

__all__ = ["DataCockpit"]
